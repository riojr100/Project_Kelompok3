package com.example.uts_lab_kenndysusio_00000075031

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.database.*

class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var databaseRef: DatabaseReference
    private lateinit var storyAdapter: FirebaseRecyclerAdapter<Story, StoryViewHolder>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Referensi ke node 'stories' di Firebase Realtime Database
        databaseRef = FirebaseDatabase.getInstance().getReference("stories")

        // Menggunakan FirebaseRecyclerOptions dengan event listener untuk data real-time
        val options = FirebaseRecyclerOptions.Builder<Story>()
            .setQuery(databaseRef, Story::class.java)
            .setLifecycleOwner(this) // Menambahkan LifecycleOwner agar adapter berhenti secara otomatis
            .build()

        // Inisialisasi FirebaseRecyclerAdapter
        storyAdapter = object : FirebaseRecyclerAdapter<Story, StoryViewHolder>(options) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
                val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_story, parent, false)
                return StoryViewHolder(view)
            }

            override fun onBindViewHolder(holder: StoryViewHolder, position: Int, model: Story) {
                holder.bind(model)
            }

            override fun onDataChanged() {
                super.onDataChanged()
                // Dijalankan setiap kali data berubah, misalnya setelah posting baru diunggah
                recyclerView.smoothScrollToPosition(itemCount) // Scroll ke posisi posting terbaru
            }
        }

        recyclerView.adapter = storyAdapter
        return view
    }

    override fun onStart() {
        super.onStart()
        storyAdapter.startListening() // Mulai mendengarkan perubahan data di Firebase
    }

    override fun onStop() {
        super.onStop()
        storyAdapter.stopListening() // Hentikan mendengarkan perubahan data
    }

    // ViewHolder class untuk RecyclerView
    class StoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val storyImage: ImageView = itemView.findViewById(R.id.story_image)
        private val storyCaption: TextView = itemView.findViewById(R.id.story_caption)

        fun bind(story: Story) {
            storyCaption.text = story.caption
            // Menggunakan Glide untuk memuat gambar dari URL Firebase Storage
            Glide.with(itemView.context)
                .load(story.imageUrl)
                .into(storyImage)
        }
    }
}
