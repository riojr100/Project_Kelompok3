package com.example.uts_lab_kenndysusio_00000075031

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.uts_lab_kenndysusio_00000075031.ProfileFragment
import com.example.uts_lab_kenndysusio_00000075031.HomeFragment

import com.google.android.material.bottomnavigation.BottomNavigationView

//kenndy - 00000075031
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Tampilkan HomeFragment sebagai default ketika aplikasi dibuka setelah login
        if (savedInstanceState == null) {
            // Set HomeFragment sebagai halaman pertama
            supportFragmentManager.beginTransaction().replace(R.id.fragment_container, HomeFragment()).commit()
        }

        // Setup navigasi menggunakan BottomNavigation
        val bottomNav: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNav.selectedItemId = R.id.nav_home // Set Home sebagai pilihan default di BottomNavigation
        bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, HomeFragment()).commit()
                    true
                }
                R.id.nav_post -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, PostingFragment()).commit()
                    true
                }
                R.id.nav_profile -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, ProfileFragment()).commit()
                    true
                }
                else -> false
            }
        }
    }
}
