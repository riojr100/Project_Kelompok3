package com.example.uts_lab_kenndysusio_00000075031

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

//kenndy
class PostingFragment : Fragment() {

    private lateinit var selectedImageView: ImageView
    private lateinit var storyEditText: EditText
    private var selectedImageUri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_post, container, false)

        // Inisialisasi view
        selectedImageView = view.findViewById(R.id.selected_image)
        storyEditText = view.findViewById(R.id.story_text)

        val selectImageButton: ImageButton = view.findViewById(R.id.select_image_button)
        selectImageButton.setOnClickListener {
            openGallery() // Membuka galeri untuk memilih gambar
        }

        val publishButton: ImageButton = view.findViewById(R.id.publish_button)
        publishButton.setOnClickListener {
            publishPost(view) // Mengunggah gambar dan cerita
        }

        return view
    }

    // Membuka galeri untuk memilih gambar
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    // Hasil dari galeri
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data
            selectedImageView.visibility = View.VISIBLE
            selectedImageView.setImageURI(selectedImageUri)
        }
    }

    // Fungsi untuk mengunggah gambar dan menyimpan cerita di Firebase
    private fun publishPost(view: View) {
        val storyText = storyEditText.text.toString()

        // Cek jika gambar sudah dipilih dan teks tidak kosong
        if (selectedImageUri != null && storyText.isNotEmpty()) {
            // Unggah gambar ke Firebase Storage
            val storageRef = FirebaseStorage.getInstance().reference.child("story_images")
            val imageRef = storageRef.child(System.currentTimeMillis().toString() + ".jpg")
            val uploadTask = imageRef.putFile(selectedImageUri!!)

            // Jika unggah berhasil
            uploadTask.addOnSuccessListener {
                imageRef.downloadUrl.addOnSuccessListener { uri ->
                    val imageUrl = uri.toString() // URL gambar di Firebase Storage

                    // Simpan cerita di Firebase Realtime Database
                    val databaseRef = FirebaseDatabase.getInstance().getReference("stories")
                    val storyId = databaseRef.push().key
                    val story = Story(imageUrl, storyText)

                    if (storyId != null) {
                        databaseRef.child(storyId).setValue(story).addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                // Tampilkan Snackbar sebagai notifikasi di bagian bawah layar
                                Snackbar.make(view, "Post berhasil diunggah", Snackbar.LENGTH_LONG).show()

                                // Reset input setelah posting
                                resetInputs()

                                // Pindah ke MainActivity secara manual
                                moveToHomePage()
                            } else {
                                Toast.makeText(
                                    context,
                                    "Story failed to publish",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            }.addOnFailureListener {
                // Tangani jika unggah gagal
                Toast.makeText(context, "Upload failed: ${it.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        } else {
            // Beri peringatan jika gambar atau teks kosong
            Toast.makeText(context, "Please enter text and select an image", Toast.LENGTH_SHORT)
                .show()
        }
    }

    // Fungsi untuk reset input setelah posting
    private fun resetInputs() {
        selectedImageUri = null
        selectedImageView.visibility = View.GONE // Sembunyikan kembali ImageView
        storyEditText.text.clear() // Kosongkan EditText
    }

    // Fungsi untuk berpindah ke halaman Home (MainActivity)
    private fun moveToHomePage() {
        val intent = Intent(requireContext(), MainActivity::class.java)  // Pindah ke MainActivity
        startActivity(intent)
        activity?.finish()  // Menutup fragment saat ini agar tidak kembali ke halaman ini
    }

    companion object {
        private const val GALLERY_REQUEST_CODE = 1234
    }
}
