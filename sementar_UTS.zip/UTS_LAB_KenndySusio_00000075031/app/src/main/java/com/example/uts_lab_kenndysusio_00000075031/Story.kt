package com.example.uts_lab_kenndysusio_00000075031

data class Story(
    val imageUrl: String = "",
    val caption: String = ""
)
